"use client"

import { useRef } from "react"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"
import { ChevronLeft, ChevronRight, Clock } from "lucide-react"
import { getUpcomingEvents, getEventCommentary, NETWORK_COLORS, SPORT_COLORS, type Network, type Event } from "@/lib/schedule-data"

function NetworkBadge({ network }: { network: Network }) {
  const colors = NETWORK_COLORS[network]
  return (
    <span className={`px-2 py-0.5 text-xs font-bold rounded ${colors.bg} ${colors.text}`}>
      {network}
    </span>
  )
}

function SportBadge({ sport }: { sport: string }) {
  const bgColor = SPORT_COLORS[sport] || "bg-gray-500"
  return (
    <span className={`px-2 py-0.5 text-xs font-medium rounded-full text-white ${bgColor}`}>
      {sport}
    </span>
  )
}

function formatTime(date: Date): string {
  return date.toLocaleTimeString("en-US", {
    hour: "numeric",
    minute: "2-digit",
    hour12: true,
  })
}

export default function ComingUpNext() {
  const scrollRef = useRef<HTMLDivElement>(null)
  const upcomingEvents = getUpcomingEvents()

  const scroll = (direction: "left" | "right") => {
    if (scrollRef.current) {
      const scrollAmount = 300
      scrollRef.current.scrollBy({
        left: direction === "left" ? -scrollAmount : scrollAmount,
        behavior: "smooth",
      })
    }
  }

  return (
    <section>
      <div className="flex items-center justify-between mb-2">
        <h2 className="text-lg font-semibold text-foreground">Coming Up Next</h2>
        <div className="flex gap-1.5">
          <Button
            variant="outline"
            size="icon"
            className="h-7 w-7 bg-transparent"
            onClick={() => scroll("left")}
            aria-label="Scroll left"
          >
            <ChevronLeft className="h-4 w-4" />
          </Button>
          <Button
            variant="outline"
            size="icon"
            className="h-7 w-7 bg-transparent"
            onClick={() => scroll("right")}
            aria-label="Scroll right"
          >
            <ChevronRight className="h-4 w-4" />
          </Button>
        </div>
      </div>

      <div
        ref={scrollRef}
        className="flex gap-3 overflow-x-auto pb-2 scrollbar-hide scroll-smooth"
        style={{ scrollbarWidth: "none", msOverflowStyle: "none" }}
      >
        {upcomingEvents.map((event) => (
          <Card
            key={event.id}
            className="flex-shrink-0 w-56 hover:shadow-md transition-shadow cursor-pointer bg-card border-border"
          >
            <CardContent className="p-2">
              <div className="flex items-center justify-between mb-1">
                <NetworkBadge network={event.network} />
                <div className="flex items-center gap-1 text-muted-foreground">
                  <Clock className="h-3 w-3" />
                  <span className="text-xs">{formatTime(event.startTime)}</span>
                </div>
              </div>

              <h3 className="font-medium text-foreground mb-1 text-sm line-clamp-1">
                {event.name}
              </h3>

              <div className="flex items-center justify-between gap-1">
                <SportBadge sport={event.sport} />
                <Popover>
                  <PopoverTrigger asChild>
                    <button
                      type="button"
                      className="px-2 py-0.5 text-xs font-medium rounded-full bg-secondary text-secondary-foreground hover:bg-secondary/80 transition-colors"
                    >
                      Preview
                    </button>
                  </PopoverTrigger>
                  <PopoverContent className="w-72 p-3" align="end">
                    <div className="space-y-2">
                      <div className="flex items-center gap-2">
                        <SportBadge sport={event.sport} />
                        <span className="text-xs text-muted-foreground">Commentary</span>
                      </div>
                      <p className="text-sm text-foreground leading-relaxed">
                        {getEventCommentary(event)}
                      </p>
                    </div>
                  </PopoverContent>
                </Popover>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </section>
  )
}
