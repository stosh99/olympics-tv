"use client"

import { useState, useEffect } from "react"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"

import { getLiveEvents, getEventCommentary, NETWORK_COLORS, SPORT_COLORS, type Network, type Event } from "@/lib/schedule-data"

function NetworkBadge({ network }: { network: Network }) {
  const colors = NETWORK_COLORS[network]
  return (
    <span className={`px-2 py-1 text-xs font-bold rounded ${colors.bg} ${colors.text}`}>
      {network}
    </span>
  )
}

function SportBadge({ sport }: { sport: string }) {
  const bgColor = SPORT_COLORS[sport] || "bg-gray-500"
  return (
    <span className={`px-2 py-0.5 text-xs font-medium rounded-full text-white ${bgColor}`}>
      {sport}
    </span>
  )
}

function CountdownTimer({ endTime }: { endTime: Date }) {
  const [timeLeft, setTimeLeft] = useState("")

  useEffect(() => {
    const updateTimer = () => {
      const now = new Date()
      const diff = endTime.getTime() - now.getTime()
      if (diff <= 0) {
        setTimeLeft("Ending soon")
        return
      }
      const hours = Math.floor(diff / (1000 * 60 * 60))
      const minutes = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60))
      const seconds = Math.floor((diff % (1000 * 60)) / 1000)
      setTimeLeft(
        hours > 0 
          ? `${hours}h ${minutes}m remaining`
          : `${minutes}:${seconds.toString().padStart(2, "0")} remaining`
      )
    }

    updateTimer()
    const interval = setInterval(updateTimer, 1000)
    return () => clearInterval(interval)
  }, [endTime])

  return <span className="text-sm text-muted-foreground">{timeLeft}</span>
}

export default function WhatsOnNow() {
  const liveEvents = getLiveEvents()

  return (
    <section>
      <div className="flex items-center gap-2 mb-2">
        <span className="relative flex h-2.5 w-2.5">
          <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-red-400 opacity-75"></span>
          <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-red-500"></span>
        </span>
        <h2 className="text-lg font-semibold text-foreground">What's On Now</h2>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
        {liveEvents.map((event) => (
          <Card
            key={event.id}
            className="overflow-hidden hover:shadow-lg transition-shadow cursor-pointer bg-card border-border"
          >
            <CardContent className="p-2">
              <div className="flex items-center justify-between mb-1">
                <NetworkBadge network={event.network} />
                <Badge variant="destructive" className="text-xs font-semibold animate-pulse">
                  LIVE
                </Badge>
              </div>

              <h3 className="font-semibold text-foreground mb-1 line-clamp-1 text-sm">
                {event.name}
              </h3>

              <div className="flex items-center justify-between gap-1">
                <SportBadge sport={event.sport} />
                <CountdownTimer endTime={event.endTime} />
                <Popover>
                  <PopoverTrigger asChild>
                    <button
                      type="button"
                      className="px-2 py-0.5 text-xs font-medium rounded-full bg-secondary text-secondary-foreground hover:bg-secondary/80 transition-colors"
                    >
                      Preview
                    </button>
                  </PopoverTrigger>
                  <PopoverContent className="w-72 p-3" align="start">
                    <div className="space-y-2">
                      <div className="flex items-center gap-2">
                        <SportBadge sport={event.sport} />
                        <span className="text-xs text-muted-foreground">Commentary</span>
                      </div>
                      <p className="text-sm text-foreground leading-relaxed">
                        {getEventCommentary(event)}
                      </p>
                    </div>
                  </PopoverContent>
                </Popover>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </section>
  )
}
