"use client"

import { useState, useEffect } from "react"

const OlympicRings = () => (
  <svg width="160" height="80" viewBox="0 0 100 48" className="shrink-0">
    <circle cx="20" cy="18" r="10" fill="none" stroke="#0085C7" strokeWidth="3" />
    <circle cx="50" cy="18" r="10" fill="none" stroke="#000000" strokeWidth="3" />
    <circle cx="80" cy="18" r="10" fill="none" stroke="#DF0024" strokeWidth="3" />
    <circle cx="35" cy="30" r="10" fill="none" stroke="#F4C300" strokeWidth="3" />
    <circle cx="65" cy="30" r="10" fill="none" stroke="#009F3D" strokeWidth="3" />
  </svg>
)

export default function Header() {
  const [currentTime, setCurrentTime] = useState(new Date())

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentTime(new Date())
    }, 1000)
    return () => clearInterval(timer)
  }, [])

  const formatDate = (date: Date) => {
    return date.toLocaleDateString("en-US", {
      weekday: "short",
      month: "short",
      day: "numeric",
      year: "numeric",
    })
  }

  const formatTime = (date: Date) => {
    return date.toLocaleTimeString("en-US", {
      hour: "numeric",
      minute: "2-digit",
      second: "2-digit",
      hour12: true,
    })
  }

  return (
    <header className="sticky top-0 z-50 bg-card border-b border-border shadow-sm">
      <div className="relative mx-auto px-4 py-5">
        {/* Centered Content */}
        <div className="flex flex-col items-center">
          <OlympicRings />
          <p className="text-sm tracking-[0.3em] text-muted-foreground font-medium mt-2">
            MILANO CORTINA
          </p>
          <h1 className="text-3xl md:text-4xl font-bold text-foreground leading-tight">
            Winter Olympics 2026
          </h1>
          <p className="text-base text-muted-foreground">
            February 6 - 22, 2026
          </p>
        </div>

        {/* Current Date and Time - positioned bottom right */}
        <div className="absolute bottom-3 right-4 text-right">
          <p className="text-xs text-muted-foreground">{formatDate(currentTime)}</p>
          <p className="text-sm font-semibold text-foreground tabular-nums">{formatTime(currentTime)}</p>
        </div>
      </div>
    </header>
  )
}
