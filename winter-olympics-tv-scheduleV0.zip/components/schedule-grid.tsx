"use client"

import { useState, useRef, useMemo, useEffect } from "react"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"
import { Calendar, ChevronLeft, ChevronRight, Globe, Tv } from "lucide-react"
import {
  generateEvents,
  generateAllEvents,
  NETWORKS,
  UNIQUE_SPORTS,
  SPORT_COLORS,
  NETWORK_COLORS,
  VENUES,
  type Network,
  type ViewMode,
  type Event,
} from "@/lib/schedule-data"

const TIME_SLOTS = Array.from({ length: 36 }, (_, i) => {
  const hour = Math.floor(i / 2) + 6
  const minute = i % 2 === 0 ? "00" : "30"
  const displayHour = hour > 12 ? hour - 12 : hour === 0 ? 12 : hour
  const ampm = hour >= 12 ? "PM" : "AM"
  return {
    value: `${hour}:${minute}`,
    label: `${displayHour}:${minute} ${ampm}`,
    hour,
    minute: parseInt(minute),
  }
})

const TIMEZONES = [
  { value: "EST", label: "Eastern (EST)" },
  { value: "CST", label: "Central (CST)" },
  { value: "MST", label: "Mountain (MST)" },
  { value: "PST", label: "Pacific (PST)" },
  { value: "CET", label: "Central European (CET)" },
]

function formatDate(date: Date): string {
  return date.toLocaleDateString("en-US", {
    weekday: "short",
    month: "short",
    day: "numeric",
  })
}

function detectUserTimezone(): string {
  try {
    const tz = Intl.DateTimeFormat().resolvedOptions().timeZone
    // Map common US timezones to our timezone options
    if (tz.includes("America/New_York") || tz.includes("America/Detroit") || tz.includes("America/Indiana")) {
      return "EST"
    } else if (tz.includes("America/Chicago") || tz.includes("America/Menominee")) {
      return "CST"
    } else if (tz.includes("America/Denver") || tz.includes("America/Phoenix") || tz.includes("America/Boise")) {
      return "MST"
    } else if (tz.includes("America/Los_Angeles") || tz.includes("America/Anchorage")) {
      return "PST"
    } else if (tz.includes("Europe/")) {
      return "CET"
    }
    // Default based on UTC offset
    const offset = new Date().getTimezoneOffset()
    if (offset === 300 || offset === 240) return "EST" // -5 or -4 (DST)
    if (offset === 360 || offset === 300) return "CST" // -6 or -5 (DST)
    if (offset === 420 || offset === 360) return "MST" // -7 or -6 (DST)
    if (offset === 480 || offset === 420) return "PST" // -8 or -7 (DST)
    return "EST" // fallback
  } catch {
    return "EST"
  }
}

export default function ScheduleGrid() {
  const [selectedDate, setSelectedDate] = useState(new Date())
  const [timezone, setTimezone] = useState<string>("")
  const [selectedSport, setSelectedSport] = useState<string | null>(null)
  const [checkedSports, setCheckedSports] = useState<Set<string>>(new Set())
  const [showCheckedOnly, setShowCheckedOnly] = useState(false)
  const [viewMode, setViewMode] = useState<ViewMode>("tv")
  const gridRef = useRef<HTMLDivElement>(null)

  // Detect user's timezone on mount
  useEffect(() => {
    setTimezone(detectUserTimezone())
  }, [])

  // Generate events based on view mode
  const events = useMemo(() => {
    if (viewMode === "all") {
      return generateAllEvents(selectedDate)
    }
    return generateEvents(selectedDate, true) // Always include Olympics.com streaming events
  }, [selectedDate, viewMode])

  // Determine which sports have events on the selected date
  const sportsWithEvents = useMemo(() => {
    const sportSet = new Set(events.map((e) => e.sport))
    return sportSet
  }, [events])

  const filteredEvents = useMemo(() => {
    if (showCheckedOnly && checkedSports.size > 0) {
      return events.filter((e) => checkedSports.has(e.sport))
    }
    if (selectedSport) {
      return events.filter((e) => e.sport === selectedSport)
    }
    return events
  }, [events, selectedSport, showCheckedOnly, checkedSports])

  const toggleCheckedSport = (sport: string) => {
    setCheckedSports((prev) => {
      const newSet = new Set(prev)
      if (newSet.has(sport)) {
        newSet.delete(sport)
      } else {
        newSet.add(sport)
      }
      return newSet
    })
  }

  const selectSingleSport = (sport: string) => {
    setShowCheckedOnly(false)
    setSelectedSport(selectedSport === sport ? null : sport)
  }

  const showCheckedSports = () => {
    if (checkedSports.size > 0) {
      setSelectedSport(null)
      setShowCheckedOnly(true)
    }
  }

  const showAllSports = () => {
    setSelectedSport(null)
    setShowCheckedOnly(false)
  }

  const changeDate = (days: number) => {
    const newDate = new Date(selectedDate)
    newDate.setDate(newDate.getDate() + days)
    setSelectedDate(newDate)
  }

  const scrollGrid = (direction: "left" | "right") => {
    if (gridRef.current) {
      const scrollAmount = 300
      gridRef.current.scrollBy({
        left: direction === "left" ? -scrollAmount : scrollAmount,
        behavior: "smooth",
      })
    }
  }

  const getEventsForRowAndTime = (rowKey: string, hour: number, minute: number, isNetworkView: boolean) => {
    return filteredEvents.filter((e) => {
      const eventHour = e.startTime.getHours()
      const eventMinute = e.startTime.getMinutes()
      const timeMatches = eventHour === hour && eventMinute === minute

      if (isNetworkView) {
        return e.network === rowKey && timeMatches
      } else {
        // For "All Events" view, group by sport or venue
        return e.sport === rowKey && timeMatches
      }
    })
  }

  const getEventDuration = (event: Event) => {
    const durationMs = event.endTime.getTime() - event.startTime.getTime()
    const durationSlots = Math.ceil(durationMs / (30 * 60 * 1000))
    return Math.min(durationSlots, 4) // Cap at 4 slots (2 hours)
  }

  // Determine which sports are in the filtered events
  const filteredSports = useMemo(() => {
    return new Set(filteredEvents.map((e) => e.sport))
  }, [filteredEvents])

  // Determine rows based on view mode
  const rows = useMemo(() => {
    if (viewMode === "tv") {
      return NETWORKS
    } else {
      // All Events view - group by sport, but only show sports that match current filter
      return UNIQUE_SPORTS.filter((sport) => filteredSports.has(sport))
    }
  }, [viewMode, filteredSports])

  const isNetworkView = viewMode === "tv"

  const getEventCommentary = (event: Event): string => {
    // Placeholder implementation for getEventCommentary
    return "Commentary for " + event.name
  }

  return (
    <section>
      <div className="flex flex-col gap-2 mb-2">
        {/* Controls Row */}
        <div className="flex flex-col sm:flex-row gap-4 items-start sm:items-center justify-between">
          <h2 className="text-xl font-semibold text-foreground">Schedule</h2>

          <div className="flex flex-wrap gap-3 items-center">
            {/* View Toggle */}
            <div className="flex items-center bg-card border border-border rounded-lg p-1">
              <Button
                variant={viewMode === "tv" ? "default" : "ghost"}
                size="sm"
                onClick={() => setViewMode("tv")}
                className="text-xs gap-1.5"
              >
                <Tv className="h-3.5 w-3.5" />
                TV Schedule
              </Button>
              <Button
                variant={viewMode === "all" ? "default" : "ghost"}
                size="sm"
                onClick={() => setViewMode("all")}
                className="text-xs gap-1.5"
              >
                <Globe className="h-3.5 w-3.5" />
                All Events
              </Button>
            </div>

            {/* Date Picker */}
            <div className="flex items-center gap-2 bg-card border border-border rounded-lg p-1">
              <Button
                variant="ghost"
                size="icon"
                className="h-8 w-8"
                onClick={() => changeDate(-1)}
                aria-label="Previous day"
              >
                <ChevronLeft className="h-4 w-4" />
              </Button>
              <div className="flex items-center gap-2 px-2">
                <Calendar className="h-4 w-4 text-muted-foreground" />
                <span className="text-sm font-medium min-w-[100px] text-center">
                  {formatDate(selectedDate)}
                </span>
              </div>
              <Button
                variant="ghost"
                size="icon"
                className="h-8 w-8"
                onClick={() => changeDate(1)}
                aria-label="Next day"
              >
                <ChevronRight className="h-4 w-4" />
              </Button>
            </div>

            {/* Timezone Selector */}
            <Select value={timezone} onValueChange={setTimezone}>
              <SelectTrigger className="w-[180px] bg-card">
                <Globe className="h-4 w-4 mr-2 text-muted-foreground" />
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {TIMEZONES.map((tz) => (
                  <SelectItem key={tz.value} value={tz.value}>
                    {tz.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </div>

        {/* Sport Filters */}
        <div className="flex flex-wrap gap-2 items-center">
          <Button
            variant={!selectedSport && !showCheckedOnly ? "default" : "outline"}
            size="sm"
            onClick={showAllSports}
            className="text-xs"
          >
            All Sports
          </Button>
          {UNIQUE_SPORTS.map((sport) => {
            const hasEvents = sportsWithEvents.has(sport)
            const isChecked = checkedSports.has(sport)
            const isSelected = selectedSport === sport
            return (
              <div
                key={sport}
                className={`inline-flex items-center rounded-md border text-xs font-medium transition-colors ${
                  isSelected
                    ? "bg-primary text-primary-foreground border-primary"
                    : "bg-card border-border hover:bg-secondary/50"
                } ${!hasEvents ? "opacity-40" : ""}`}
              >
                {/* Checkbox area - clicking only toggles checkbox */}
                <button
                  type="button"
                  onClick={(e) => {
                    e.stopPropagation()
                    if (hasEvents) toggleCheckedSport(sport)
                  }}
                  disabled={!hasEvents}
                  className={`flex items-center justify-center h-8 w-8 border-r ${
                    isSelected ? "border-primary-foreground/20" : "border-border"
                  } ${hasEvents ? "hover:bg-black/5 cursor-pointer" : "cursor-not-allowed"}`}
                  aria-label={`Check ${sport}`}
                >
                  <div
                    className={`w-3.5 h-3.5 rounded border-2 flex items-center justify-center transition-colors ${
                      isChecked
                        ? isSelected
                          ? "bg-primary-foreground border-primary-foreground"
                          : "bg-primary border-primary"
                        : isSelected
                          ? "border-primary-foreground/50"
                          : "border-muted-foreground/50"
                    }`}
                  >
                    {isChecked && (
                      <svg
                        className={`w-2.5 h-2.5 ${isSelected ? "text-primary" : "text-primary-foreground"}`}
                        fill="none"
                        viewBox="0 0 24 24"
                        stroke="currentColor"
                        strokeWidth={3}
                      >
                        <path strokeLinecap="round" strokeLinejoin="round" d="M5 13l4 4L19 7" />
                      </svg>
                    )}
                  </div>
                </button>
                {/* Sport name area - clicking selects only this sport */}
                <button
                  type="button"
                  onClick={() => hasEvents && selectSingleSport(sport)}
                  disabled={!hasEvents}
                  className={`flex items-center gap-1.5 h-8 px-3 ${
                    hasEvents ? "cursor-pointer" : "cursor-not-allowed"
                  }`}
                >
                  <span
                    className={`w-2 h-2 rounded-full ${SPORT_COLORS[sport] || "bg-gray-400"}`}
                  />
                  {sport}
                </button>
              </div>
            )
          })}
          {/* Show Checked button */}
          <Button
            variant={showCheckedOnly ? "default" : "outline"}
            size="sm"
            onClick={showCheckedSports}
            disabled={checkedSports.size === 0}
            className={`text-xs ${checkedSports.size === 0 ? "opacity-40" : ""}`}
          >
            Show Checked ({checkedSports.size})
          </Button>
          {/* Grid Scroll Controls - right justified */}
          <div className="flex gap-1.5 ml-auto">
            <Button
              variant="outline"
              size="icon"
              className="h-7 w-7 bg-transparent"
              onClick={() => scrollGrid("left")}
              aria-label="Scroll left"
            >
              <ChevronLeft className="h-4 w-4" />
            </Button>
            <Button
              variant="outline"
              size="icon"
              className="h-7 w-7 bg-transparent"
              onClick={() => scrollGrid("right")}
              aria-label="Scroll right"
            >
              <ChevronRight className="h-4 w-4" />
            </Button>
          </div>
        </div>
      </div>

      {/* Schedule Grid */}
      <Card className="overflow-hidden bg-card border-border">
        <CardContent className="p-0">
          <div className="flex">
            {/* Row Labels (Fixed) */}
            <div className="flex-shrink-0 bg-secondary border-r border-border">
              <div className="h-12 border-b border-border" />
              {rows.map((row) => (
                <div
                  key={row}
                  className={`h-14 flex items-center justify-center px-3 border-b border-border ${
                    row === "Olympics.com" ? "bg-slate-50" : ""
                  }`}
                >
                  {isNetworkView ? (
                    <span
                      className={`px-3 py-1.5 text-xs font-bold rounded whitespace-nowrap ${
                        NETWORK_COLORS[row as Network]?.bg || "bg-gray-500"
                      } ${NETWORK_COLORS[row as Network]?.text || "text-white"}`}
                    >
                      {row}
                    </span>
                  ) : (
                    <div className="flex items-center gap-2">
                      <span
                        className={`w-3 h-3 rounded-full ${SPORT_COLORS[row] || "bg-gray-400"}`}
                      />
                      <span className="text-xs font-medium text-foreground whitespace-nowrap max-w-[100px] truncate">
                        {row}
                      </span>
                    </div>
                  )}
                </div>
              ))}
            </div>

            {/* Scrollable Time Slots */}
            <div
              ref={gridRef}
              className="flex-1 overflow-x-auto"
              style={{ scrollbarWidth: "thin" }}
            >
              <div className="min-w-max">
                {/* Time Headers */}
                <div className="flex border-b border-border bg-secondary">
                  {TIME_SLOTS.map((slot) => (
                    <div
                      key={slot.value}
                      className="w-32 flex-shrink-0 px-2 py-3 text-center text-xs font-medium text-muted-foreground border-r border-border"
                    >
                      {slot.label}
                    </div>
                  ))}
                </div>

                {/* Rows */}
                {rows.map((row) => {
                  const isOlympicsRow = row === "Olympics.com"
                  return (
                    <div
                      key={row}
                      className={`flex h-14 border-b border-border ${
                        isOlympicsRow ? "bg-slate-50/50" : ""
                      }`}
                    >
                      {TIME_SLOTS.map((slot) => {
                        const cellEvents = getEventsForRowAndTime(
                          row,
                          slot.hour,
                          slot.minute,
                          isNetworkView
                        )
                        return (
                          <div
                            key={`${row}-${slot.value}`}
                            className={`w-32 flex-shrink-0 p-1 border-r border-border relative transition-colors ${
                              isOlympicsRow
                                ? "bg-slate-50/30 hover:bg-slate-100/50"
                                : "bg-card hover:bg-secondary/50"
                            }`}
                          >
                            {cellEvents.map((event) => {
                              const duration = getEventDuration(event)
                              const sportColor = SPORT_COLORS[event.sport] || "bg-gray-500"
                              const isStreaming = event.network === "Olympics.com"

                              return (
                                <Popover key={event.id}>
                                  <PopoverTrigger asChild>
                                    <div
                                      className={`absolute top-0.5 left-0.5 right-0.5 bottom-0.5 rounded-md px-1.5 py-1 cursor-pointer hover:ring-2 hover:ring-ring transition-all overflow-hidden ${sportColor} ${
                                        isStreaming ? "opacity-70" : ""
                                      }`}
                                      style={{
                                        width: `calc(${duration * 100}% + ${(duration - 1) * 8}px - 4px)`,
                                        zIndex: 10,
                                      }}
                                    >
                                      <div className="flex flex-col h-full justify-between">
                                        <p className="text-[11px] font-semibold text-white line-clamp-1 leading-tight">
                                          {event.name}
                                          {viewMode === "all" && event.televisedNetwork && (
                                            <span className="ml-1 inline-flex items-center">
                                              <Tv className="h-2.5 w-2.5 text-white/90" />
                                            </span>
                                          )}
                                        </p>
                                        <div className="flex items-center justify-between">
                                          <div className="flex items-center gap-0.5">
                                            {event.isLive ? (
                                              <Badge
                                                variant="destructive"
                                                className="text-[9px] px-1 py-0 h-3.5"
                                              >
                                                LIVE
                                              </Badge>
                                            ) : (
                                              <Badge
                                                variant="secondary"
                                                className="text-[9px] px-1 py-0 h-3.5 bg-white/20 text-white"
                                              >
                                                REPLAY
                                              </Badge>
                                            )}
                                            {isStreaming && (
                                              <Badge
                                                variant="secondary"
                                                className="text-[9px] px-1 py-0 h-3.5 bg-white/30 text-white"
                                              >
                                                STREAM
                                              </Badge>
                                            )}
                                          </div>
                                          <span className="text-[9px] text-white/80 font-medium">
                                            Preview
                                          </span>
                                        </div>
                                      </div>
                                    </div>
                                  </PopoverTrigger>
                                  <PopoverContent className="w-72 p-3" align="start">
                                    <div className="space-y-2">
                                      <div className="flex items-center gap-2">
                                        <span
                                          className={`w-3 h-3 rounded-full ${sportColor}`}
                                        />
                                        <span className="text-sm font-medium">{event.sport}</span>
                                        <span className="text-xs text-muted-foreground">Commentary</span>
                                      </div>
                                      <p className="text-sm font-semibold">{event.name}</p>
                                      <p className="text-sm text-foreground leading-relaxed">
                                        {getEventCommentary(event)}
                                      </p>
                                    </div>
                                  </PopoverContent>
                                </Popover>
                              )
                            })}
                          </div>
                        )
                      })}
                    </div>
                  )
                })}
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* View Mode Legend */}
      <div className="mt-4 flex flex-wrap gap-4 text-xs text-muted-foreground">
        {viewMode === "combined" && (
          <div className="flex items-center gap-2">
            <div className="w-4 h-4 bg-slate-200 rounded opacity-70" />
            <span>Olympics.com streaming only (not on US TV)</span>
          </div>
        )}
        {viewMode === "all" && (
          <div className="flex items-center gap-2">
            <Tv className="h-4 w-4" />
            <span>Events with TV icon are being televised on US networks</span>
          </div>
        )}
      </div>
    </section>
  )
}
