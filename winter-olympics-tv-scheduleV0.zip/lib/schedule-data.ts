export type Network = "NBC" | "USA" | "CNBC" | "Peacock" | "Olympics.com"

export type ViewMode = "tv" | "all"

export const VENUES = [
  "Cortina d'Ampezzo",
  "Bormio Sliding Centre",
  "Arena di Verona",
  "Milano Santa Giulia",
  "Livigno",
  "Anterselva",
  "Predazzo",
  "Val di Fiemme",
] as const

export type Venue = (typeof VENUES)[number]

export type Sport =
  | "Alpine Skiing"
  | "Biathlon"
  | "Bobsled"
  | "Cross-Country Skiing"
  | "Curling"
  | "Figure Skating"
  | "Freestyle Skiing"
  | "Ice Hockey"
  | "Luge"
  | "Nordic Combined"
  | "Short Track"
  | "Skeleton"
  | "Ski Jumping"
  | "Snowboard"
  | "Speed Skating"
  | "Skeleton"

export const ALL_SPORTS: Sport[] = [
  "Alpine Skiing",
  "Biathlon",
  "Bobsled",
  "Cross-Country Skiing",
  "Curling",
  "Figure Skating",
  "Freestyle Skiing",
  "Ice Hockey",
  "Luge",
  "Nordic Combined",
  "Short Track",
  "Skeleton",
  "Ski Jumping",
  "Snowboard",
  "Speed Skating",
  "Skeleton",
]

// Ensure exactly 16 unique sports
export const SPORTS: Sport[] = [
  "Alpine Skiing",
  "Biathlon",
  "Bobsled",
  "Cross-Country Skiing",
  "Curling",
  "Figure Skating",
  "Freestyle Skiing",
  "Ice Hockey",
  "Luge",
  "Nordic Combined",
  "Short Track",
  "Skeleton",
  "Ski Jumping",
  "Snowboard",
  "Speed Skating",
  "Speed Skating", // duplicate will be filtered, we add one more
]

export const UNIQUE_SPORTS: string[] = [
  "Alpine Skiing",
  "Biathlon",
  "Bobsled",
  "Cross-Country Skiing",
  "Curling",
  "Figure Skating",
  "Freestyle Skiing",
  "Ice Hockey",
  "Luge",
  "Nordic Combined",
  "Short Track",
  "Skeleton",
  "Ski Jumping",
  "Snowboard",
  "Speed Skating",
  "Freestyle Aerials",
]

export const NETWORKS: Network[] = ["NBC", "Peacock", "USA", "CNBC", "Olympics.com"]

export const NETWORK_COLORS: Record<Network, { bg: string; text: string }> = {
  NBC: { bg: "bg-gradient-to-r from-red-500 via-yellow-500 to-green-500", text: "text-white" },
  USA: { bg: "bg-blue-600", text: "text-white" },
  CNBC: { bg: "bg-emerald-600", text: "text-white" },
  Peacock: { bg: "bg-gradient-to-r from-blue-500 via-purple-500 to-pink-500", text: "text-white" },
  "Olympics.com": { bg: "bg-slate-500", text: "text-white" },
}

export const SPORT_COLORS: Record<string, string> = {
  "Alpine Skiing": "bg-sky-500",
  "Biathlon": "bg-amber-600",
  "Bobsled": "bg-slate-700",
  "Cross-Country Skiing": "bg-green-600",
  "Curling": "bg-red-500",
  "Figure Skating": "bg-pink-500",
  "Freestyle Skiing": "bg-orange-500",
  "Ice Hockey": "bg-blue-700",
  "Luge": "bg-indigo-600",
  "Nordic Combined": "bg-teal-600",
  "Short Track": "bg-rose-600",
  "Skeleton": "bg-zinc-600",
  "Ski Jumping": "bg-cyan-600",
  "Snowboard": "bg-violet-600",
  "Speed Skating": "bg-emerald-500",
  "Freestyle Aerials": "bg-yellow-600",
}

export interface Event {
  id: string
  name: string
  sport: string
  network: Network
  startTime: Date
  endTime: Date
  isLive: boolean
  isReplay: boolean
  venue?: Venue
  isTelevisedElsewhere?: boolean
  televisedNetwork?: Network
}

// Generate commentary for an event
export function getEventCommentary(event: Event): string {
  const commentaryTemplates: Record<string, string[]> = {
    "Alpine Skiing": [
      "Watch for Mikaela Shiffrin as she attempts to add another medal to her collection. Course conditions are excellent with fresh snow overnight.",
      "Marco Odermatt is the favorite heading into this event. The Italian crowd will be electric at Cortina d'Ampezzo.",
      "This could be one of the most competitive fields we've seen. Pay attention to the middle section where many racers have struggled in practice.",
    ],
    "Biathlon": [
      "Johannes Thingnes Bø leads the World Cup standings and is looking dominant. His shooting accuracy has been exceptional this season.",
      "The wind conditions could play a major factor in the shooting stages. Athletes with steadier nerves will have an advantage.",
      "France's Quentin Fillon Maillet is seeking redemption after a disappointing previous Olympics. He's been training specifically for this course.",
    ],
    "Figure Skating": [
      "The Japanese contingent is expected to dominate with their technical prowess. Watch for quad attempts in the free skate.",
      "This pairs event features several teams attempting throw quad salchows for the first time in Olympic competition.",
      "The ice dance competition is wide open this year with at least five teams capable of medaling.",
    ],
    "Ice Hockey": [
      "This matchup features the top two ranked teams in the tournament. Expect a physical, fast-paced game with playoff intensity.",
      "Goaltending will be crucial in this contest. Both teams have elite netminders capable of stealing the game.",
      "The rivalry between these two nations adds extra drama to an already high-stakes elimination game.",
    ],
    "Curling": [
      "Strategy will be key in this match between two tactically brilliant teams. Watch for aggressive play in the early ends.",
      "The ice conditions have been tricky, causing some unexpected stone behavior. Teams that adapt quickly will have an edge.",
      "This mixed doubles final features the reigning world champions against Olympic newcomers with nothing to lose.",
    ],
  }

  const defaultCommentary = [
    `Don't miss this exciting ${event.sport} event featuring top athletes from around the world competing for Olympic glory.`,
    `${event.sport} action continues with medal hopes on the line. The competition has been fierce and today should be no different.`,
    `Athletes have been preparing years for this moment. Expect personal bests and potentially world records in this ${event.sport} event.`,
  ]

  const templates = commentaryTemplates[event.sport] || defaultCommentary
  const index = Math.abs(event.id.split("").reduce((a, b) => a + b.charCodeAt(0), 0)) % templates.length
  return templates[index]
}

// Generate sample events for the schedule
export function generateEvents(date: Date, includeStreaming = false): Event[] {
  const events: Event[] = []
  const sports = UNIQUE_SPORTS

  // Generate events for each network across the day
  NETWORKS.forEach((network, networkIndex) => {
    let currentHour = 6 + networkIndex // Start at different times for variety

    while (currentHour < 24) {
      const sportIndex = (currentHour + networkIndex) % sports.length
      const duration = Math.random() > 0.5 ? 1 : 1.5 // 1 or 1.5 hours
      const isLive = Math.random() > 0.4
      const startTime = new Date(date)
      startTime.setHours(currentHour, currentHour % 2 === 0 ? 0 : 30, 0, 0)

      const endTime = new Date(startTime)
      endTime.setMinutes(endTime.getMinutes() + duration * 60)

      const venueIndex = (currentHour + networkIndex) % VENUES.length

      events.push({
        id: `${network}-${currentHour}-${sportIndex}`,
        name: getEventName(sports[sportIndex]),
        sport: sports[sportIndex],
        network,
        startTime,
        endTime,
        isLive,
        isReplay: !isLive,
        venue: VENUES[venueIndex],
      })

      currentHour += duration + 0.5 // Add gap between events
    }
  })

  // Generate Olympics.com streaming-only events (not televised on US networks)
  if (includeStreaming) {
    let streamingHour = 5
    while (streamingHour < 23) {
      const sportIndex = streamingHour % sports.length
      const duration = Math.random() > 0.5 ? 1 : 1.5
      const startTime = new Date(date)
      startTime.setHours(streamingHour, streamingHour % 3 === 0 ? 0 : 30, 0, 0)

      const endTime = new Date(startTime)
      endTime.setMinutes(endTime.getMinutes() + duration * 60)

      const venueIndex = streamingHour % VENUES.length

      events.push({
        id: `olympics-${streamingHour}-${sportIndex}`,
        name: getEventName(sports[sportIndex]),
        sport: sports[sportIndex],
        network: "Olympics.com",
        startTime,
        endTime,
        isLive: Math.random() > 0.3,
        isReplay: false,
        venue: VENUES[venueIndex],
      })

      streamingHour += duration + 1
    }
  }

  return events
}

// Generate all events grouped by sport/venue for "All Events" view
export function generateAllEvents(date: Date): Event[] {
  const events: Event[] = []
  const sports = UNIQUE_SPORTS

  sports.forEach((sport, sportIndex) => {
    const venueIndex = sportIndex % VENUES.length
    let currentHour = 6 + (sportIndex % 4)

    // Generate 2-4 events per sport throughout the day
    const numEvents = 2 + (sportIndex % 3)
    for (let i = 0; i < numEvents && currentHour < 22; i++) {
      const duration = 1 + Math.random() * 1.5
      const startTime = new Date(date)
      startTime.setHours(currentHour, i % 2 === 0 ? 0 : 30, 0, 0)

      const endTime = new Date(startTime)
      endTime.setMinutes(endTime.getMinutes() + duration * 60)

      // Determine if this event is televised
      const isTelevisedOnUS = Math.random() > 0.3
      const televisedNetwork = isTelevisedOnUS ? NETWORKS[i % NETWORKS.length] : undefined

      events.push({
        id: `all-${sport}-${currentHour}-${i}`,
        name: getEventName(sport),
        sport,
        network: televisedNetwork || "Olympics.com",
        startTime,
        endTime,
        isLive: currentHour >= 8 && currentHour <= 20 && Math.random() > 0.4,
        isReplay: false,
        venue: VENUES[venueIndex],
        isTelevisedElsewhere: isTelevisedOnUS,
        televisedNetwork,
      })

      currentHour += duration + 2 + (i * 1.5)
    }
  })

  return events.sort((a, b) => a.startTime.getTime() - b.startTime.getTime())
}

function getEventName(sport: string): string {
  const eventTypes: Record<string, string[]> = {
    "Alpine Skiing": ["Men's Downhill", "Women's Giant Slalom", "Men's Super-G", "Women's Slalom"],
    "Biathlon": ["Men's 10km Sprint", "Women's 15km Individual", "Mixed Relay"],
    "Bobsled": ["2-Man Heat 1", "4-Man Final", "Women's Monobob"],
    "Cross-Country Skiing": ["Men's 15km Classic", "Women's Skiathlon", "Team Sprint"],
    "Curling": ["USA vs Sweden", "Canada vs Norway", "Mixed Doubles Final"],
    "Figure Skating": ["Men's Short Program", "Ice Dance Free", "Pairs Final"],
    "Freestyle Skiing": ["Halfpipe Finals", "Moguls Qualifying", "Slopestyle Final"],
    "Ice Hockey": ["USA vs Canada", "Finland vs Sweden", "Women's Quarterfinal"],
    "Luge": ["Men's Singles Run 3", "Women's Doubles", "Team Relay"],
    "Nordic Combined": ["Individual Gundersen", "Team Event", "Large Hill"],
    "Short Track": ["500m Heats", "1500m Final", "Relay Semifinal"],
    "Skeleton": ["Men's Heat 2", "Women's Final", "Training Run"],
    "Ski Jumping": ["Normal Hill Final", "Large Hill Qualifying", "Team Event"],
    "Snowboard": ["Halfpipe Final", "Giant Slalom", "Snowboard Cross"],
    "Speed Skating": ["5000m Final", "1500m Heats", "Team Pursuit"],
    "Freestyle Aerials": ["Men's Final", "Women's Qualifying", "Mixed Team"],
  }
  const types = eventTypes[sport] || ["Event"]
  return types[Math.floor(Math.random() * types.length)]
}

export function getLiveEvents(): Event[] {
  const now = new Date()
  return [
    {
      id: "live-1",
      name: "Men's Giant Slalom - Run 2",
      sport: "Alpine Skiing",
      network: "NBC",
      startTime: new Date(now.getTime() - 30 * 60000),
      endTime: new Date(now.getTime() + 45 * 60000),
      isLive: true,
      isReplay: false,
    },
    {
      id: "live-2",
      name: "Women's Ice Dance Free",
      sport: "Figure Skating",
      network: "USA",
      startTime: new Date(now.getTime() - 15 * 60000),
      endTime: new Date(now.getTime() + 90 * 60000),
      isLive: true,
      isReplay: false,
    },
    {
      id: "live-3",
      name: "USA vs Canada",
      sport: "Ice Hockey",
      network: "CNBC",
      startTime: new Date(now.getTime() - 45 * 60000),
      endTime: new Date(now.getTime() + 30 * 60000),
      isLive: true,
      isReplay: false,
    },
    {
      id: "live-4",
      name: "Halfpipe Final",
      sport: "Snowboard",
      network: "Peacock",
      startTime: new Date(now.getTime() - 20 * 60000),
      endTime: new Date(now.getTime() + 60 * 60000),
      isLive: true,
      isReplay: false,
    },
  ]
}

export function getUpcomingEvents(): Event[] {
  const now = new Date()
  return [
    {
      id: "upcoming-1",
      name: "Men's Downhill",
      sport: "Alpine Skiing",
      network: "NBC",
      startTime: new Date(now.getTime() + 60 * 60000),
      endTime: new Date(now.getTime() + 150 * 60000),
      isLive: false,
      isReplay: false,
    },
    {
      id: "upcoming-2",
      name: "Mixed Relay",
      sport: "Biathlon",
      network: "USA",
      startTime: new Date(now.getTime() + 90 * 60000),
      endTime: new Date(now.getTime() + 180 * 60000),
      isLive: false,
      isReplay: false,
    },
    {
      id: "upcoming-3",
      name: "2-Man Bobsled Final",
      sport: "Bobsled",
      network: "CNBC",
      startTime: new Date(now.getTime() + 120 * 60000),
      endTime: new Date(now.getTime() + 210 * 60000),
      isLive: false,
      isReplay: false,
    },
    {
      id: "upcoming-4",
      name: "Women's 1500m",
      sport: "Speed Skating",
      network: "Peacock",
      startTime: new Date(now.getTime() + 150 * 60000),
      endTime: new Date(now.getTime() + 240 * 60000),
      isLive: false,
      isReplay: false,
    },
    {
      id: "upcoming-5",
      name: "Team Relay",
      sport: "Luge",
      network: "NBC",
      startTime: new Date(now.getTime() + 180 * 60000),
      endTime: new Date(now.getTime() + 270 * 60000),
      isLive: false,
      isReplay: false,
    },
    {
      id: "upcoming-6",
      name: "USA vs Sweden",
      sport: "Curling",
      network: "USA",
      startTime: new Date(now.getTime() + 210 * 60000),
      endTime: new Date(now.getTime() + 300 * 60000),
      isLive: false,
      isReplay: false,
    },
    {
      id: "upcoming-7",
      name: "Normal Hill Final",
      sport: "Ski Jumping",
      network: "CNBC",
      startTime: new Date(now.getTime() + 240 * 60000),
      endTime: new Date(now.getTime() + 330 * 60000),
      isLive: false,
      isReplay: false,
    },
    {
      id: "upcoming-8",
      name: "500m Heats",
      sport: "Short Track",
      network: "Peacock",
      startTime: new Date(now.getTime() + 270 * 60000),
      endTime: new Date(now.getTime() + 360 * 60000),
      isLive: false,
      isReplay: false,
    },
  ]
}

export interface Commentary {
  id: string
  sport: string
  headline: string
  preview: string
  author: string
  updatedMinutesAgo: number
  spoilerContent: string
}

export const commentaryData: Commentary[] = [
  {
    id: "c1",
    sport: "Alpine Skiing",
    headline: "Mikaela Shiffrin Eyes Historic Gold in Giant Slalom",
    preview: "The American star looks to add to her record medal haul as she takes on a challenging course in Cortina...",
    author: "Sarah Martinez",
    updatedMinutesAgo: 5,
    spoilerContent: "Shiffrin leads after the first run with a time of 1:02.34, 0.47 seconds ahead of Switzerland's Lara Gut-Behrami.",
  },
  {
    id: "c2",
    sport: "Figure Skating",
    headline: "Ice Dance Final Set to Deliver Drama",
    preview: "The rivalry between the French and Canadian pairs reaches its climax tonight as they compete for gold...",
    author: "Michael Chen",
    updatedMinutesAgo: 12,
    spoilerContent: "After the rhythm dance, France leads with 90.12 points, narrowly ahead of Canada at 89.78.",
  },
  {
    id: "c3",
    sport: "Ice Hockey",
    headline: "USA vs Canada: The Rivalry Renewed",
    preview: "Both teams bring their A-game to this highly anticipated semifinal matchup with a spot in the gold medal game...",
    author: "David Thompson",
    updatedMinutesAgo: 3,
    spoilerContent: "End of 2nd period: USA 2, Canada 2. Auston Matthews with two goals for USA.",
  },
  {
    id: "c4",
    sport: "Snowboard",
    headline: "Halfpipe Finals: New Generation Takes Over",
    preview: "Young athletes are pushing the boundaries of what's possible in the pipe, with multiple triple corks expected...",
    author: "Emma Wilson",
    updatedMinutesAgo: 8,
    spoilerContent: "Japan's Ayumu Hirano leads after Run 1 with a score of 96.25.",
  },
]
